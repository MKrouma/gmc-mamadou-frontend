module.exports = {
  client: {
    service: {
      url: "http://localhost:4000",
      skipSSLValidation: true,
    },
  },
};
