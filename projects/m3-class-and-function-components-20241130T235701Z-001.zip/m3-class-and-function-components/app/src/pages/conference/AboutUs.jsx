import * as React from "react";

export function AboutUs() {
  return (
    <div className="container">
      <div className="row">
        <div className="col-xs-12" style={{ padding: 5 }}>
          <h4>
            We aim to bring the best and brightest from around the world to
            learn with us. Please mind our Code of Conduct. We hope you enjoy
            our conference.
          </h4>
        </div>
      </div>
    </div>
  );
}
